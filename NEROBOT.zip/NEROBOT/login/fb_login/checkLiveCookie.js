module.exports = async function () {
	return true; // i will set the real func if i got 50 follower in github (;
};
