modules.exports = async () => {}; //I will set the working functions if i got 200 follower IN my github soo plz follow me: https://github.com/Varnosbit/ here.
